import { createRequire } from 'node:module';
import { spawnSync } from 'node:child_process';
import { randomBytes, randomUUID, createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';

const backend = '/workspace/startup/systems/enterprise-admin/backend';
const artifacts = '/workspace/test-artifacts/products-low-stock-pagination';
const require = createRequire(path.join(backend, 'package.json'));
const { PrismaClient, Prisma } = require('@prisma/client');
const phase = process.argv[2];
const stateFile = path.join(artifacts, 'isolated-database.json');
const state = phase === 'bootstrap' ? {
    adminUrl: 'postgresql://test@127.0.0.1:55434/checkout_http_recovery_base',
    name: `checkout_http_recovery_inventory_pagination_${randomUUID().replaceAll('-', '')}`,
} : JSON.parse(readFileSync(stateFile, 'utf8'));
const databaseUrl = `postgresql://test@127.0.0.1:55434/${state.name}`;
const url = new URL(databaseUrl);
if (url.hostname !== '127.0.0.1' || url.port !== '55434' || url.username !== 'test' || url.password
    || !/^checkout_http_recovery_inventory_pagination_[a-z0-9_]+$/.test(state.name)) throw new Error('Synthetic database guard failed');

const env = Object.fromEntries(['PATH', 'HOME', 'LANG', 'LC_ALL', 'TMPDIR'].flatMap((key) =>
    process.env[key] ? [[key, process.env[key]]] : []));
Object.assign(env, {
    DATABASE_URL: databaseUrl, PRODUCT_PAGINATION_DATABASE_URL: databaseUrl,
    NODE_ENV: 'test', TZ: 'UTC', CORS_ORIGIN: 'http://localhost:5173',
    JWT_ACCESS_SECRET: randomBytes(32).toString('hex'),
    JWT_REFRESH_SECRET: randomBytes(32).toString('hex'),
    JWT_ACCESS_EXPIRES_IN: '15m', JWT_REFRESH_EXPIRES_IN: '7d', PORT: '3000',
    QUICKBOOKS_CLIENT_ID: '', QUICKBOOKS_CLIENT_SECRET: '', XERO_CLIENT_ID: '', XERO_CLIENT_SECRET: '',
    LINE_CHANNEL_ACCESS_TOKEN: '', LINE_CHANNEL_SECRET: '', DOTENV_CONFIG_QUIET: 'true',
});
const trackedHead = spawnSync('git', ['rev-parse', 'HEAD'], { cwd: backend, encoding: 'utf8' }).stdout.trim();
const sources = Object.fromEntries([
    'src/modules/inventory/inventory.service.ts',
    'src/modules/inventory/__tests__/products-pagination.test.ts',
    'src/__tests__/products-pagination.integration.test.ts',
].map((file) => [file, createHash('sha256').update(readFileSync(path.join(backend, file))).digest('hex')]));

function run(file, args, rawName) {
    const started = new Date().toISOString();
    const result = spawnSync(file, args, { cwd: backend, env, encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 });
    const raw = (result.stdout ?? '') + (result.stderr ?? '');
    writeFileSync(path.join(artifacts, rawName), raw);
    writeFileSync(path.join(artifacts, rawName + '.execution.json'), JSON.stringify({
        command: [file, ...args], cwd: backend, started, ended: new Date().toISOString(),
        exit_code: result.status, signal: result.signal, spawn_error: result.error?.message ?? null,
        tracked_head: trackedHead, working_tree_source_sha256: sources,
        synthetic_database: { host: url.hostname, port: url.port, database: state.name, user: url.username },
        environment_keys: Object.keys(env).sort(),
        credential_policy: 'JWT secrets generated in memory per invocation, never recorded. Optional external integrations set empty. DATABASE_URL explicit guarded synthetic database.',
    }, null, 2) + '\n');
    process.stdout.write(raw);
    console.log(JSON.stringify({ raw: rawName, exit_code: result.status, signal: result.signal, spawn_error: result.error?.message ?? null }));
    if (result.status !== 0 || result.error) process.exit(result.status || 1);
}

if (phase === 'bootstrap') {
    const db = new PrismaClient({ datasourceUrl: state.adminUrl });
    try {
        const metadata = await db.$queryRaw`SELECT current_database() AS database, version() AS version`;
        if (metadata[0].database !== 'checkout_http_recovery_base') throw new Error('Existing synthetic admin DB mismatch');
        await db.$executeRawUnsafe(`CREATE DATABASE "${state.name}"`);
        writeFileSync(stateFile, JSON.stringify({ ...state, databaseUrl, owned: true, metadata, prisma_version: Prisma.prismaVersion,
            created: new Date().toISOString(), tracked_head: trackedHead }, null, 2) + '\n');
        console.log(JSON.stringify({ created_owned_synthetic_database: state.name, metadata, prisma_version: Prisma.prismaVersion }));
    } finally { await db.$disconnect(); }
    run(process.execPath, ['node_modules/prisma/build/index.js', 'migrate', 'deploy'], '10-migrate-existing-schema.txt');
    run(process.execPath, ['--import', 'tsx', 'prisma/seed.ts'], '11-existing-synthetic-seed.txt');
} else if (phase === 'focused') {
    run('npm', ['test', '--', 'src/modules/inventory/__tests__/products-pagination.test.ts', 'src/__tests__/products-pagination.integration.test.ts'], '12-real-prisma-focused.txt');
} else if (phase === 'full') {
    run('npm', ['test'], '13-full-backend.txt');
} else if (phase === 'cleanup') {
    if (!state.owned) throw new Error('Refuse cleanup of unowned DB');
    const db = new PrismaClient({ datasourceUrl: state.adminUrl });
    try {
        await db.$executeRawUnsafe(`DROP DATABASE "${state.name}"`);
        const record = { dropped_owned_database: state.name, exit_code: 0, timestamp: new Date().toISOString() };
        writeFileSync(path.join(artifacts, '20-owned-database-cleanup.json'), JSON.stringify(record, null, 2) + '\n');
        console.log(JSON.stringify(record));
    } finally { await db.$disconnect(); }
} else throw new Error(`Unknown phase: ${phase}`);
